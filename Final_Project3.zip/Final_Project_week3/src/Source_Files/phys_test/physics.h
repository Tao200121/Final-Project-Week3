#ifndef PHYSICS_H
#define PHYSICS_H

int x_position(int x, int delt_x);
int y_position(int y, int delt_y);

#endif